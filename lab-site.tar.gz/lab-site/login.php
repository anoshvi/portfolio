<?php
// Demo login. Sets a session cookie -> inherently uncacheable.
// A good target for a WAF custom rule and/or rate limiting.
session_start();

$error = null;
$loggedIn = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $user = $_POST['username'] ?? '';
  $pass = $_POST['password'] ?? '';
  // Demo credentials only. NOT real security.
  if ($user === 'demo' && $pass === 'demo') {
    $_SESSION['user'] = $user;
    setcookie('lab_session', bin2hex(random_bytes(16)), [
      'expires'  => time() + 3600,
      'path'     => '/',
      'secure'   => true,
      'httponly' => true,
      'samesite' => 'Lax',
    ]);
    $loggedIn = true;
  } else {
    $error = 'Invalid credentials (try demo / demo).';
  }
}

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login — lab.anoshvi.uk</title>
  <link rel="stylesheet" href="/style.css" />
</head>
<body>
  <header class="nav">
    <div class="container nav-inner">
      <a href="/index.html" class="brand">Anosh<span>.</span></a>
      <nav aria-label="Primary">
        <a href="/index.html">Home</a>
        <a href="/lab.html">Lab</a>
      </nav>
    </div>
  </header>
  <main>
    <section class="page-head"><div class="container"><p class="eyebrow">Auth</p><h1>Login</h1></div></section>
    <section class="section"><div class="container" style="max-width:460px;">
      <?php if ($loggedIn): ?>
        <div class="card"><p>✅ Logged in as <strong><?= htmlspecialchars($_SESSION['user']) ?></strong>. A <code>lab_session</code> cookie was set — this response is uncacheable.</p></div>
      <?php else: ?>
        <?php if ($error): ?><div class="card" style="border-color:#ef4444;margin-bottom:16px;"><p><?= htmlspecialchars($error) ?></p></div><?php endif; ?>
        <form class="card" method="POST" action="/login.php">
          <p style="margin-top:0;color:var(--muted);">Demo form (credentials: <code>demo</code> / <code>demo</code>). Use this path to demo WAF/rate-limiting.</p>
          <label>Username<br><input name="username" style="width:100%;padding:10px;margin:6px 0 14px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--text);"></label>
          <label>Password<br><input name="password" type="password" style="width:100%;padding:10px;margin:6px 0 18px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--text);"></label>
          <button class="btn primary" type="submit" style="border:0;cursor:pointer;">Log in</button>
        </form>
      <?php endif; ?>
    </div></section>
  </main>
  <footer class="footer"><div class="container"><p>© <span id="year"></span> Anosh Viccaji. Served from an origin VM behind Cloudflare.</p></div></footer>
  <script src="/script.js" defer></script>
</body>
</html>
