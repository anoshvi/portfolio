<?php
// Dynamic, server-computed time endpoint. Intentionally UNCACHEABLE.
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$now = new DateTime('now', new DateTimeZone('UTC'));
echo json_encode([
  'service'   => 'lab.anoshvi.uk time api',
  'source'    => 'server-side (php on origin vm)',
  'iso_8601'  => $now->format('Y-m-d\TH:i:s\Z'),
  'unix_s'    => $now->getTimestamp(),
  'timezone'  => 'UTC',
  'served_by' => gethostname(),
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
echo "\n";
