<?php
// Shows how the request arrived through Cloudflare. UNCACHEABLE.
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function h($k) { return $_SERVER[$k] ?? null; }

echo json_encode([
  'client_ip_seen_by_origin' => h('REMOTE_ADDR'),
  'cf_connecting_ip'         => h('HTTP_CF_CONNECTING_IP'),
  'cf_ray'                   => h('HTTP_CF_RAY'),
  'cf_ipcountry'             => h('HTTP_CF_IPCOUNTRY'),
  'x_forwarded_for'          => h('HTTP_X_FORWARDED_FOR'),
  'x_forwarded_proto'        => h('HTTP_X_FORWARDED_PROTO'),
  'host'                     => h('HTTP_HOST'),
  'method'                   => h('REQUEST_METHOD'),
  'path'                     => h('REQUEST_URI'),
  'user_agent'               => h('HTTP_USER_AGENT'),
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
echo "\n";
