<?php
// Reflects a query parameter. Useful target for a custom WAF rule
// (e.g. block SQLi-like patterns in ?q=) and managed ruleset demos.
$q = isset($_GET['q']) ? (string)$_GET['q'] : '';
header('Cache-Control: no-store');
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Search — lab.anoshvi.uk</title>
  <link rel="stylesheet" href="/style.css" />
</head>
<body>
  <header class="nav">
    <div class="container nav-inner">
      <a href="/index.html" class="brand">Anosh<span>.</span></a>
      <nav aria-label="Primary"><a href="/index.html">Home</a><a href="/lab.html">Lab</a></nav>
    </div>
  </header>
  <main>
    <section class="page-head"><div class="container"><p class="eyebrow">Search</p><h1>Search</h1></div></section>
    <section class="section"><div class="container" style="max-width:640px;">
      <form class="card" method="GET" action="/search.php" style="margin-bottom:18px;">
        <input name="q" value="<?= htmlspecialchars($q, ENT_QUOTES) ?>" placeholder="Type a query…"
               style="width:100%;padding:10px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--text);">
        <p style="color:var(--muted);font-size:13px;margin:10px 0 0;">Tip: this <code>?q=</code> param is a good target for a custom WAF rule.</p>
      </form>
      <?php if ($q !== ''): ?>
        <div class="card"><p>You searched for: <strong><?= htmlspecialchars($q, ENT_QUOTES) ?></strong></p><p style="color:var(--muted);">(No real results — this is a demo endpoint.)</p></div>
      <?php endif; ?>
    </div></section>
  </main>
  <footer class="footer"><div class="container"><p>© <span id="year"></span> Anosh Viccaji. Served from an origin VM behind Cloudflare.</p></div></footer>
  <script src="/script.js" defer></script>
</body>
</html>
