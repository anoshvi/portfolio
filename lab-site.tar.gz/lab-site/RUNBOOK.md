# Deploy lab.anoshvi.uk portfolio to the VM

## What this is
A multi-page portfolio (mirrors the GitHub site) **plus** dynamic PHP endpoints,
designed so you can configure and demo Cache Rules, Transform/Redirect/Origin Rules,
and WAF/rate-limiting on top of it.

## Files
- Static: `index.html`, `about.html`, `projects.html`, `skills.html`, `gallery.html`,
  `contact.html`, `lab.html`, `style.css`, `script.js`, `images/*.svg`, `api/*.json`
- Dynamic (PHP): `api/time.php`, `api/whoami.php`, `login.php`, `search.php`
- Mock restricted area: `admin/index.html`

## Deploy steps (Google SSH-in-browser)
1. In the Cloudflare Core Lab VM SSH window, click **UPLOAD FILE** and upload `lab-site.tar.gz`.
2. In the shell:
   ```bash
   cd ~
   tar -xzf lab-site.tar.gz
   cd lab-site
   sudo bash deploy.sh
   ```
3. Verify on the VM:
   ```bash
   curl -sI http://localhost/ | head -5
   curl -s  http://localhost/api/time.php
   curl -sI http://localhost/login.php | grep -i set-cookie
   ```
4. Verify through Cloudflare (from anywhere):
   ```bash
   curl -sI https://lab.anoshvi.uk/ | grep -iE 'server|cf-ray'
   curl -sI https://lab.anoshvi.uk/images/banner.svg | grep -i cf-cache-status   # run twice
   curl -sI https://lab.anoshvi.uk/api/time.php | grep -iE 'cache-control|cf-cache-status'
   ```

## Endpoint map (what each demonstrates)
| Path | Type | Use in demo |
|------|------|-------------|
| `/`, `*.html` | static HTML | cacheable content |
| `/images/*.svg`, `/style.css`, `/script.js` | static assets | cached by default (HIT) |
| `/api/*.json` | static JSON | add a Cache Rule to cache it |
| `/api/time.php` | dynamic | `no-store` → BYPASS/DYNAMIC |
| `/api/whoami.php` | dynamic | shows CF-Connecting-IP / cf-ray |
| `/login.php` | dynamic | sets cookie → target for rate limiting / WAF |
| `/search.php?q=` | dynamic | reflects param → custom WAF rule target |
| `/admin/` | static (mock) | lock down with a custom WAF rule |

## Rollback
Original docroot is backed up to `/var/www/html.bak`:
```bash
sudo rm -rf /var/www/html && sudo mv /var/www/html.bak /var/www/html && sudo systemctl reload apache2
```
