#!/usr/bin/env bash
# Deploy the lab.anoshvi.uk portfolio to this Apache server.
# Run ON the VM after uploading and extracting lab-site.tar.gz.
# Usage:  sudo bash deploy.sh
set -euo pipefail

DOCROOT="/var/www/html"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Source: $SRC_DIR"
echo "==> Docroot: $DOCROOT"

# 1) Ensure PHP + headers module are available
if ! command -v php >/dev/null 2>&1; then
  echo "==> PHP not found. Installing libapache2-mod-php..."
  apt-get update -y
  apt-get install -y libapache2-mod-php php
fi
a2enmod php* 2>/dev/null || true
a2enmod headers 2>/dev/null || true
a2enmod rewrite 2>/dev/null || true

# 2) Back up the existing docroot once
if [ ! -d "${DOCROOT}.bak" ]; then
  echo "==> Backing up existing docroot to ${DOCROOT}.bak"
  cp -a "$DOCROOT" "${DOCROOT}.bak" || true
fi

# 3) Copy site files into docroot (exclude deploy artifacts)
echo "==> Copying site files into $DOCROOT"
rm -f "$DOCROOT/index.html" 2>/dev/null || true
cp -R "$SRC_DIR"/. "$DOCROOT"/
rm -f "$DOCROOT/deploy.sh" "$DOCROOT/RUNBOOK.md" 2>/dev/null || true

# 4) Permissions
echo "==> Setting ownership/permissions"
chown -R www-data:www-data "$DOCROOT"
find "$DOCROOT" -type d -exec chmod 755 {} \;
find "$DOCROOT" -type f -exec chmod 644 {} \;

# 5) Reload Apache
echo "==> Reloading Apache"
systemctl reload apache2 || apachectl -k graceful || service apache2 reload

echo
echo "==> Done. Test locally on the VM:"
echo "    curl -sI http://localhost/ | head -5"
echo "    curl -s  http://localhost/api/time.php"
echo "    curl -sI http://localhost/login.php | grep -i set-cookie"
